Each one of these can be modified to being pushed to a specific case, each case can be modified to have the color you want inside of it.

(HEX) Means you can just change the hex value directly.
(PUSH) Means you are pushing to a specific color case.

Extras:

//Requires more investigation:
0098A79B -->  (Codecave for white) Get_Basic_Font for nametags, quest names and experience/item drop color.


## **CUI WINDOW RELATED SKILL/STAT ~**

0098B70C -->  Character Stats on Character Selection (HEX)
![[Pasted image 20240326181917.png]]





## CUIStatDetail::OnCreate (Thanks Windyboy <3)


**Stat Detail Back Button Position**:

 008C274F  --> Y coord (HEX)
![[Pasted image 20240327220650.png]]
 008C2754  --> X coord (HEX)
![[Pasted image 20240327220533.png]]




## CUIStatDetail::CUIStatDetail

**Render Limit for Stat Window**

008C5105 --> Y coord (HEX)
008C510A --> X coord (HEX)
![[Pasted image 20240328014817.png]]




## CUIStatDetail::Draw

**Stat Detail Text Positions:**

**Attack**
 008C3400 --> Y coord (HEX)
  008C3402 --> X coord (HEX)
![[Pasted image 20240327214924.png]]


**Weapon Def** 
008C35C9 --> Y coord (HEX)
008C35CB --> X coord (HEX)
![[Pasted image 20240327212236.png]]


**Magic**
008C374A -->  Y coord (HEX)
008C374C -->  X coord (HEX)
![[Pasted image 20240327215240.png]]


**Magic Def**
008C35C9 -->  Y coord (HEX)
008C39EB -->  X coord (HEX)
![[Pasted image 20240327213211.png]]


**Accuracy**
008C3B9C -->  Y coord (HEX)
008C3B9E -->  X coord (HEX)
![[Pasted image 20240327213646.png]]


**Avoidability**
008C3B9C -->  Y coord (HEX)
008C3B9E -->  X coord (HEX)
![[Pasted image 20240327213841.png]]


**Hands**
008C3F8E -->  Y coord (HEX)
008C3F90 -->  X coord (HEX)
![[Pasted image 20240327214027.png]]


**Speed**
008C435A -->  Y coord (HEX)
008C435F  -->  X coord (HEX)
![[Pasted image 20240327214405.png]]


**Jump**
008C4444 -->  Y coord (HEX)
008C4449 -->  X coord (HEX)
![[Pasted image 20240327214606.png]]



008C2898 --> Stat Detail Numbers without buff (PUSH)
![[Pasted image 20240327173152.png]]


008C28C6 --> Stat Detail Numbers buff (PUSH)
![[Pasted image 20240327204702.png]]


008C28C6 --> Stat Detail Numbers debuffed (PUSH)  [Probably not used!]

008C28A8 -->  [Probably not used!]




## **CUIStat**::Draw

**Name**
008C5A9C --> Y coord (HEX)
008C5A9E --> X coord (HEX)
![[Pasted image 20240327234359.png]]

**Job**
008C5B67 --> Y coord (HEX)
008C5B69 --> X coord (HEX)
![[Pasted image 20240327234656.png]]

**Level**
008C5C73 --> Y coord (HEX) 
008C5C75 --> X coord (HEX)
![[Pasted image 20240327234951.png]]

**Guild**
008C5D2D --> Y coord (HEX)
008C5D2F --> X coord (HEX)
![[Pasted image 20240327235129.png]]

**Hp**
008C5E39 --> Y coord (HEX)
008C5E3B --> X coord (HEX)
![[Pasted image 20240327235351.png]]

**Mp**
008C5F25 --> Y coord (HEX)
008C5F2A --> X coord (HEX)
![[Pasted image 20240327235614.png]]

**Exp**
008C603F --> Y coord (HEX)
008C6044 --> X coord (HEX)
![[Pasted image 20240327235753.png]]

**Fame**
008C6121 --> Y coord (HEX)
008C6126 --> X coord (HEX)
![[Pasted image 20240328000003.png]]

**Str**
008C6564 --> Y coord (HEX)
008C6569 --> X coord (HEX)
![[Pasted image 20240328000516.png]]

**Dex**
008C66FD --> Y coord (HEX)
008C6702 --> X coord (HEX)
![[Pasted image 20240328000954.png]]

**Int**
008C6896 --> Y coord (HEX)
008C689B --> X coord (HEX)
![[Pasted image 20240328001137.png]]

**Luk**
008C6A2A --> Y coord (HEX)
008C6A2F --> X coord (HEX)
![[Pasted image 20240328001201.png]]

**Ability Point**
008C6B65 --> Y coord (HEX)
008C6B6A --> X coord (HEX)
![[Pasted image 20240328002241.png]]


## CUIStat::CUIStat

**Close Button position:**
008C4858 --> Y coord (HEX)
008C485A --> X coord (HEX)
![[Pasted image 20240327223858.png]]

**Render Limit for Stat Window**
008C4AAE --> Y coord (HEX)
008C4AB3 --> X coord (HEX)
![[Pasted image 20240328014213.png]]

008C4944 -->  Stat Window Name/Level/Job/Guild Strings (PUSH)
![[Pasted image 20240326182121.png]]

008C4995 -->  Stat Window Strings  (PUSH)
![[Pasted image 20240327224532.png]]



## CUIStat::OnCreate

**Detail Button**
008C4E1B --> Y coord (HEX)
008C4E20 --> X coord (HEX)
![[Pasted image 20240328012430.png]]




## CUISkill::CUISkill

008AA6CB --> Skill Strings  (PUSH)
![[Pasted image 20240326182303.png]]



## CWvsContext::OnDropPickUpMessage

//THIS ONE NEEDS MORE INVESTIGATION
00A20AD9 --> Individual Drop String Groups (PUSH)
![[Pasted image 20240326174552.png]]

00A20D35 --> Shadow of picked up items text address (all strings) (PUSH)
![[Pasted image 20240326153642.png]]

0089B227  --> Square around item pickup text address (HEX)
![[Pasted image 20240326153430.png]]



## CUIStatusBar::ChatLogAdd

008DB070 --> Chat background log colors, search for the cases and proceed to edit hues
CASE 11 is White background

![[Pasted image 20240325172723.png]]



## CUIStatusBar::ChatLogDraw

008DBF61 --> push 80 (000000) { (AC000804) }    //Chat box color thanks angel (HEX)
![[Pasted image 20240325175238.png]]



## CUIStatusBar::OnCreate

008D077F --> All address (GM user) (HEX)
![[Pasted image 20240325230755.png]]


008D03B6 --> All address (regular user)  (Requires codecave) (HEX)
![[Pasted image 20240325230954.png]]


008D0455 --> Whisper address (HEX)
![[Pasted image 20240326124440.png]]


008D0599 --> Notice address (HEX)
![[Pasted image 20240326124713.png]]



008D04F7 --> Reward message address (HEX)
![[Pasted image 20240326132054.png]]


008D06DD --> Item leveling address (HEX)
![[Pasted image 20240326143214.png]]


008D0821 --> Channel Notice address (HEX)
![[Pasted image 20240326143449.png]]



008D0D2E --> Buddy address (HEX)
![[Pasted image 20240326145013.png]]



008D0DD0 --> Party address (HEX)
![[Pasted image 20240326145422.png]]



008D0FB0 --> Guild address (HEX)
![[Pasted image 20240326150040.png]]



008D1052 --> Alliance address (HEX)
![[Pasted image 20240326150429.png]]



## CUIMiniMap::SetLayer

0085629A --> Minimap Minimized text (HEX)
![[Pasted image 20240327165644.png]]





## CUIMiniMap::Update

00859268 --> Minimap background layer 1 color address (HEX)
![[Pasted image 20240327143601.png]]

008592BC --> Minimap background layer 2 color address  (HEX)
![[Pasted image 20240327143959.png]]